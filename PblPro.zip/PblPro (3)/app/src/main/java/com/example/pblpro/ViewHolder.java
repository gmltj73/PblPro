package com.example.pblpro;

import android.widget.EditText;

public class ViewHolder {
    EditText editText1; //순서번호
    EditText editText2; //속성

    int ref;
}